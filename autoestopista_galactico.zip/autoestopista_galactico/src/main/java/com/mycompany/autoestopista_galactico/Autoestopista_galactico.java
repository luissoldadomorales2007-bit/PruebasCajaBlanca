package com.mycompany.autoestopista_galactico;
import java.util.Scanner;
import java.util.Random;
public class Autoestopista_galactico {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

		Random dado = new Random();



		int casilla = 1; 

		int galaxiaAnterior = calcularDireccion(0,0,0); 

		boolean juegoActivo = true;



		System.out.println("LA GUÍA DEL VIAJERO INTERGALÁCTICO");

		System.out.println("Comienzas en la casilla " + casilla + " en la galaxia 000");



		do {

			System.out.println("Escribe lo que sea para lanzar los 3 dados...");

			leer.nextLine();



			

			int d1 = dado.nextInt(9); 

			int d2 = dado.nextInt(9);

			int d3 = dado.nextInt(9);



			int galaxiaActual = calcularDireccion(d1, d2, d3);

			System.out.println("Has obtenido la galaxia: " + d1 + d2 + d3 + " valor " + galaxiaActual);



			int diferencia = Math.abs(galaxiaActual - galaxiaAnterior);



			if (diferencia <= 4) {

				casilla += diferencia;

				System.out.println("Avanzas " + diferencia + " casillas. Ahora estás en la casilla " + casilla);

			} else {

				System.out.println("Las galaxias no son cercanas. No avanzas.");

			}



			galaxiaAnterior = galaxiaActual;



			juegoActivo = comprobarEstadoJuego(casilla);



			if (casilla > 42) {

				casilla = 1;

				System.out.println("Has sobrepasado la casilla 42. Vuelves a la casilla 1.");

			}



		} while (juegoActivo);



		System.out.println("FIN DEL JUEGO");

		leer.close();

	}



	public static int calcularDireccion(int d1, int d2, int d3) {

		int suma = d1 + d2 + d3;

		while (suma >= 10) {

			suma = (suma / 10) + (suma % 10);

		}

		return suma;

	}



	public static boolean comprobarEstadoJuego(int casilla) {

		if (casilla == 31) {

			System.out.println("Extraterrestres peligrosos Retrocedes a la casilla 13.");

			return true; 

		} else if (casilla == 33) {

			System.out.println("Has caído en un agujero negro. Pierdes el juego.");

			return false; 

		} else if (casilla == 42) {

			System.out.println("Has llegado a la casilla 42 Ganaste el juego.");

			return false; 

		}

		return true; 







	}

}
